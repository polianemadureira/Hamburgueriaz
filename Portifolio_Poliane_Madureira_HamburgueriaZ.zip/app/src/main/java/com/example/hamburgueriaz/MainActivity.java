
package com.example.hamburgueriaz;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    int quantidade = 0;
    final int precoBase = 20;
    final int precoBacon = 2;
    final int precoQueijo = 2;
    final int precoOnionRings = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void somar(View view) {
        quantidade++;
        atualizarQuantidade();
    }

    public void subtrair(View view) {
        if (quantidade > 0) quantidade--;
        atualizarQuantidade();
    }

    private void atualizarQuantidade() {
        TextView qtdTextView = findViewById(R.id.txtQuantidade);
        qtdTextView.setText(String.valueOf(quantidade));
    }

    public void enviarPedido(View view) {
        EditText nomeInput = findViewById(R.id.inputNome);
        String nome = nomeInput.getText().toString();

        CheckBox bacon = findViewById(R.id.chkBacon);
        CheckBox queijo = findViewById(R.id.chkQueijo);
        CheckBox onion = findViewById(R.id.chkOnion);

        boolean temBacon = bacon.isChecked();
        boolean temQueijo = queijo.isChecked();
        boolean temOnion = onion.isChecked();

        int precoFinal = calcularPreco(temBacon, temQueijo, temOnion);

        String resumo = "Nome do cliente: " + nome +
                "\nTem Bacon? " + (temBacon ? "Sim" : "Não") +
                "\nTem Queijo? " + (temQueijo ? "Sim" : "Não") +
                "\nTem Onion Rings? " + (temOnion ? "Sim" : "Não") +
                "\nQuantidade: " + quantidade +
                "\nPreço final: R$ " + precoFinal;

        TextView resumoPedido = findViewById(R.id.txtResumo);
        resumoPedido.setText(resumo);

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_SUBJECT, "Pedido de " + nome);
        intent.putExtra(Intent.EXTRA_TEXT, resumo);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private int calcularPreco(boolean bacon, boolean queijo, boolean onion) {
        int adicionais = 0;
        if (bacon) adicionais += precoBacon;
        if (queijo) adicionais += precoQueijo;
        if (onion) adicionais += precoOnionRings;
        return (precoBase + adicionais) * quantidade;
    }
}
